# Restaurant Table Reservation & Waitlist System

Java Programming, Case Study 70 (B.Tech CSE 2025-29, Semester III).

This is a Swing desktop app for a restaurant host. It manages table reservations, the walk-in waitlist and seating across tables of different sizes and sections. When a table frees up, it tells the host which booked or waitlisted party should get it.

- Pure Java with no external libraries. It builds on **Java 8 or newer**.
- Business logic sits in a service layer, separate from the GUI.
- Data is saved automatically to `data/restaurant.dat` and restored the next time the app starts.

---

## How to run

**macOS / Linux**
```bash
./run.sh          # compile + open the GUI
```

**Windows**
```
run.bat
```

**IntelliJ / Eclipse / VS Code:** mark `src` as the source root, then run `com.restaurant.Main`.

If `javac` isn't on your PATH, point `JAVA_HOME` at a JDK:
`JAVA_HOME=/path/to/jdk ./run.sh`.

On the first run the app loads sample data: 12 tables, bookings for tomorrow, a few walk-ins already seated, and two parties on the waitlist. After that it restores whatever was saved last. The **File** menu has Save Now, Reload Saved Data, Load Sample Data and Clear All Data.

---

## Project structure

```
src/com/restaurant/
├── Main.java                         entry point: seeds data, opens GUI, starts monitor thread
├── model/
│   ├── Table.java                    physical table (number, capacity, section, status)
│   ├── Reservation.java              a booking or a seated walk-in
│   ├── Customer.java                 guest (identity = phone number)
│   ├── WaitlistEntry.java            a walk-in party waiting for a table
│   ├── Waitlist.java                 LinkedList queue of WaitlistEntry
│   ├── TableStatus.java              enum AVAILABLE / RESERVED / OCCUPIED
│   ├── ReservationStatus.java        enum CONFIRMED / SEATED / COMPLETED / CANCELLED / NO_SHOW
│   └── Section.java                  enum MAIN_HALL / PATIO / BAR / PRIVATE_ROOM
├── exception/
│   ├── RestaurantException.java      base checked exception
│   ├── InvalidReservationException.java
│   ├── InvalidTableException.java
│   ├── TableNotAvailableException.java
│   └── NotFoundException.java
├── persistence/
│   ├── DataStore.java                save/load with serialization (atomic write, corrupt-file recovery)
│   └── RestaurantSnapshot.java       everything that is saved, as one serializable object
├── util/
│   ├── Validator.java                all validation rules
│   └── TimeUtil.java                 strict date/time parsing and formatting
├── service/
│   ├── RestaurantManager.java        core logic: collections, CRUD, assignment, search, sort
│   ├── WaitlistNotifier.java         Runnable: table bussing -> availability notification
│   ├── ReservationMonitor.java       Runnable: periodic sweep (holds, late alerts, waitlist)
│   ├── ReportGenerator.java          seating report
│   ├── RestaurantListener.java       observer interface (manager -> GUI)
│   ├── NotificationType.java         INFO / WARNING / ALERT
│   ├── WalkInResult.java             "seated now" or "waitlisted at #n"
│   └── SampleData.java               demo data
└── gui/
    ├── MainFrame.java                window, tabs, live notification log, alert banner
    ├── TablesPanel.java              floor plan + table setup
    ├── ReservationsPanel.java        booking form, search, sort, check-in/cancel/delete
    ├── WaitlistPanel.java            walk-ins and waitlist queue
    ├── ReportsPanel.java             seating report (save to .txt)
    ├── StatusCellRenderer.java       colour-coded status cells
    └── GuiUtil.java                  shared Swing helpers
docs/
├── Project_Report.docx               case-study report (university template)
├── Setup_and_Run_Guide.docx          install -> run, end-to-end test checklist, troubleshooting
├── Concepts_and_Study_Guide.docx     every concept explained with this project's code
├── Viva_Questions_and_Answers.docx   viva preparation
├── Live_Demo_Script.docx             10-minute live demo script
├── uml/                              class diagram, architecture, two flowcharts (PNG + SVG)
├── screenshots/                      GUI screenshots used in the report
└── _build/                           scripts that regenerate all of the above (not part of the app)
```

---

## Required Java concepts and where they are used

| Java concept | Application | Where |
|---|---|---|
| **Classes & Objects** | Table, Reservation, Customer, Waitlist | `model/` package |
| **Constructors** | Initialise reservation/table objects | `Table(number, capacity, section)` starts `AVAILABLE`. `Reservation(...)` generates an id and starts `CONFIRMED`. `WaitlistEntry(...)` |
| **Enum** | `TableStatus` (AVAILABLE, RESERVED, OCCUPIED) | `TableStatus.java`, plus `ReservationStatus`, `Section`, and `SortField`/`SearchField`, which carry their own `Comparator` |
| **Runnable / Thread** | Simulate waitlist notification | `WaitlistNotifier` runs on a new thread each time a table is released: it sleeps (bussing time), then offers the table. `ReservationMonitor` is a daemon thread that sweeps every 15 s. All manager methods are `synchronized`, and the GUI switches back to the EDT with `SwingUtilities.invokeLater` |
| **ArrayList** | Store tables and reservations | `RestaurantManager.tables`, `RestaurantManager.reservations` |
| **LinkedList** | Waitlist queue | `Waitlist.queue`: `addLast` to join, `pollFirst`/iterator removal to seat or leave |
| **HashMap** | Reservation ID → Reservation | `RestaurantManager.reservationById`, O(1) lookup for check-in, edit, search by ID |
| **TreeMap** | Reservations sorted by time | `RestaurantManager.reservationsByTime`. `subMap` gives "due in the next 30 min", today's list and the report's upcoming list. `tailMap` gives the next booking per table |
| **CRUD** | Reservation management | `createReservation`, `getReservation`, `updateReservation`, `cancelReservation` / `markNoShow`, `deleteReservation` |
| **Searching** | By customer / table | `searchReservations(query, SearchField)`: partial name (case-insensitive), phone fragment, table number, reservation ID |
| **Sorting** | By time, party size | `RestaurantManager.sort(list, SortField, ascending)` supports time, party size, customer, table and status, ascending or descending |
| **Swing** | Reservation management GUI | `gui/` package: `JTabbedPane`, `JTable`, forms, dialogs, `javax.swing.Timer` |
| **Exception handling** | Invalid reservation/table data | Custom checked exception hierarchy under `RestaurantException`. Every GUI action catches it and shows the message |
| **Validation** | Party size, reservation time, table capacity | `Validator`: name/phone format, party size 1-20, time not in the past, within service hours (11:00-22:30), on a 15-min slot, ≤ 60 days ahead, party fits table, capacity 1-20, strict date parsing (rejects 2026-02-30) |

---

## Expected modules

1. **Table Setup** (*Floor & Tables* tab): add, edit or remove tables with number, seats and section. You can't shrink a table below a booked party or remove a table that has bookings.
2. **Reservation Booking** (*Reservations* tab): book, edit, cancel, mark no-show, or delete. The table is auto-assigned unless the host picks one.
3. **Waitlist Management** (*Walk-ins & Waitlist* tab): **Walk-in Arrived** seats the party at once if a table is free, otherwise it queues them with a position and an estimated wait. The host can also seat or remove a party.
4. **Table Assignment**: best fit, meaning the smallest free table that fits the party. The preferred section is tried first. There are no double bookings: each party blocks its table for a 90-minute dining window.
5. **Availability Notification**: the notification log and banner (with a beep) tell the host when:
   - a table is held for a reservation arriving within 30 minutes
   - a released table goes to the first waitlisted party that fits (**page guest**)
   - a booked party is more than 15 minutes late
6. **Reservation Search**: live search by customer name/phone, table, or ID, combined with sort and view filters (All / Today / Active).
7. **Seating Reports** (*Seating Reports* tab): floor status, seat utilisation, a per-section breakdown, today's parties by status, covers, average party size, peak hour, upcoming bookings and waitlist statistics. Reports can be saved as `.txt`.

### Seating rules

- **Waitlist fairness.** When a table frees up, the earliest party in the LinkedList that fits it gets it. A 2-top skips a party of 4 at the front but never skips a party that fits. A new walk-in can't take a table while someone already queued fits it.
- **Bookings protect their table.** A walk-in or waitlisted party won't get a table that a reservation needs within the next 90 minutes. The table is held for the booked party 30 minutes before they're due.
- **Held tables are released automatically.** Cancelling, marking a no-show or leaving the waitlist frees any table held for that party, and the table goes to the next party in line.

---

## Demo walkthrough (about 3 minutes)

1. **Floor & Tables**: the colours show the live floor. Table 5 is *Reserved* for waitlisted party W002, and the yellow banner says "page guest". Select table 5 and click **Seat Held Party**.
2. Select an *Occupied* patio table (7-9) and click **Release Table**. About 2 s later, the background thread holds it for Isha Verma (W001, wants Patio) and a `[READY]` notification appears.
3. **Reservations**: book a table for an hour from now, then try again with party size 25, a past time, `19:07`, or a date like `2026-02-30`. Each one gets a clear validation error. Type part of a name in Search, then sort by party size.
4. **Walk-ins & Waitlist**: add a party of 4 wanting Patio. They get queued with a position and wait estimate.
5. **Seating Reports**: click Refresh to see the numbers update.

---

## Saving data

- Every change is saved about 1.5 s later, and again when the window closes.
- Saves are atomic: the app writes a temporary file, then moves it over `data/restaurant.dat`, so a crash mid-save can't corrupt the data.
- On a restart the next day, visits left open are closed, bookings that never arrived become no-shows, and the old waitlist is cleared.
- If the data file can't be read, it's renamed to `restaurant.dat.corrupt-<time>` and the app starts with sample data.
- The HashMap and TreeMap aren't saved. They're rebuilt from the reservation list on load, so they always match it.
- To use a different file: `java -cp out com.restaurant.Main path/to/file.dat`.
