#!/usr/bin/env bash
# Compile and launch the GUI.
# Uses $JAVA_HOME/bin if JAVA_HOME is set, otherwise javac/java from PATH.
set -e
cd "$(dirname "$0")"
BIN="${JAVA_HOME:+$JAVA_HOME/bin/}"

rm -rf out && mkdir -p out
# -sourcepath lets javac pull in every class reachable from Main
"${BIN}javac" -encoding UTF-8 -d out -sourcepath src src/com/restaurant/Main.java
"${BIN}java" -cp out com.restaurant.Main
